angular.module('starter.controllersTim', [])


.controller('TermineCtrl', function($scope, $state) {

})

.controller('ExportCtrl', function($scope, $state) {

})
